# AngularRoutingTutorial
In this Angular 9 router tutorial, we will learn how to enable routing & navigation service in an Angular app. Routing allows users to navigate between one component to another component based on action taken by the user.

## Written Tutorial
[Angular 9 Router Tutorial – Configure Routing & Navigation](https://www.positronx.io/angular-router-tutorial/)
